// modules
const express = require("express");
const app = express.Router();
const {database} = require("../lib/database");

const PER_PAGE = 20;

const {
    db_err_message,
    flash_message,
    secure,
    member,
    sanitize,
    minifyDate,
    formatName
} = require("../lib/globals");


// load company info
app.get("/info/:name", (req, res) => {
    // get data from the database
    database.query(`SELECT * FROM listings INNER JOIN list_details ON list_details.list_id = listings.list_id WHERE listings.name = ?`, [req.params.name], 
    (err, results) => {
    if (err) {
        // send error to dev
        console.log(err);
        // send error to the user
        req.session.message = db_err_message;
        // go back to the previous page
        return res.redirect("back");
    }
    else if (results.length < 1) {
        // send error to the user
        req.session.message = flash_message("No listing available with this name");
        // go back to the previous page
        return res.redirect("back");
    }
    else {
        // get all kinds of data available
        var options = JSON.parse(results[0].options); 
        var public = JSON.parse(results[0].public);
        var private = JSON.parse(results[0].private);
        var premium = JSON.parse(results[0].premium);
        var list_type = results[0].type;
        var list_logo = results[0].logo;
        var list_id = results[0].list_id;
        var upload_by = results[0].upload_by;
        var categories = results[0].category_list.split(",");
        // check for any reviews
        database.query(`SELECT * FROM reviews WHERE target_list = ?`, [list_id],
        (err, results) => {
            if (err) {
                // send error to dev
                console.log(err);
                // send error to the user
                req.session.message = db_err_message;
                // go back to the previous page
                return res.redirect("back");
            }
            else {
                // calculate the reviews
                var total = 0;
                var responses = results.length;
                for (let i = 0; i < responses; i++) {
                    total += results[i].stars;
                }
                var score = total / responses;
                // load the page with all of the data
                return res.render("public/details", {
                    page: req.originalUrl,
                    title: public.name,
                    type: list_type,
                    list_id: list_id,
                    logo: list_logo,
                    uploader: upload_by,
                    categories: categories,
                    option: options,
                    public_data: public,
                    private_data: private,
                    premium_data: premium,
                    rating: score,
                    responses: responses,
                    reviews: results,
                    format: formatName,
                    minifyDate: minifyDate
                });
            }
        });
    }
    });
});


// category page 
app.get("/", (req, res) => {
    res.redirect("/list/category");
});
app.get("/all", (req, res) => {
    database.query(`SELECT * FROM listings WHERE type = ?`, ["free"], (err, results) => {
        if (err) {
            // send error to dev
            console.log(err);
            // send error to the user
            req.session.message = db_err_message;
            // go back to the previous page
            return res.redirect("back");
        } else {
            var total_results = results.length;
            var pages = Math.ceil(total_results / PER_PAGE);
            var start, end;
            if (req.query.page) {
                if (req.query.page > pages || req.query.page < 1) {
                    // send error to the user
                    req.session.message = flash_message("Invalid page number for this category");
                    // go back to the previous page
                    return res.redirect("back");
                }
                start = (req.query.page - 1) * PER_PAGE;
                end = start + PER_PAGE;
            } else {
                start = 0;
                end = 20;
            }
            results = results.slice(start, end);
            res.render("public/category-list", {
                title: "All Free Listings",
                listings: results,
                total: total_results,
                page: {
                    total: pages,
                    this: req.query.page || 1
                }
            });
        }
    });
});
app.get("/category", (req, res) => {
    if (req.query.id) {
        database.query(`SELECT * FROM categories WHERE category_id = ?`, [req.query.id],
        (err, results) => {
        if (err) {
            // send error to dev
            console.log(err);
            // send error to the user
            req.session.message = db_err_message;
            // go back to the previous page
            return res.redirect("back");
        } else if (results.length < 1) {
            // send error to the user
            req.session.message = flash_message("No category available with this ID");
            // go back to the previous page
            return res.redirect("back");
        }
        else {
            var c_name = results[0].c_name;
            var pack = [];
            database.query(`SELECT * FROM listings`, (err, results) => {
                if (err) {
                    // send error to dev
                    console.log(err);
                    // send error to the user
                    req.session.message = db_err_message;
                    // go back to the previous page
                    return res.redirect("back");
                }
                else {
                    results.forEach(list => {
                        list.category_list.split(',').forEach(name => {
                            if (name == c_name)
                                pack.push(list);
                        });
                    });

                    var total_results = pack.length;
                    var pages = Math.ceil(total_results / PER_PAGE);
                    var start, end;
                    if (req.query.page) {
                        if (req.query.page > pages || req.query.page < 1) {
                            // send error to the user
                            req.session.message = flash_message("Invalid page number for this category");
                            // go back to the previous page
                            return res.redirect("back");
                        }
                        start = (req.query.page - 1) * PER_PAGE;
                        end = start + PER_PAGE;
                    } else {
                        start = 0;
                        end = 20;
                    }
                    pack = pack.slice(start, end);
                    res.render("public/category-list", {
                        title: c_name,
                        listings: pack,
                        total: total_results,
                        page: {
                            total: pages,
                            this: req.query.page || 1
                        }
                    });
                }
            });
        }
    });
    } else {
        // basic category listings
        database.query(`SELECT * FROM categories`, (err, results) => {
        if (err) {
            // send error to dev
            console.log(err);
            // send error to the user
            req.session.message = db_err_message;
            // go back to the previous page
            return res.redirect("back");
        }
        else {
            var categories = [];
            results.forEach(data => {
                // collect category names
                var category = {
                    id: data.category_id,
                    name: data.c_name
                };
                categories.push(category);
            });
            database.query(`SELECT * FROM listings`, (err, results) => {
                if (err) {
                    // send error to dev
                    console.log(err);
                    // send error to the user
                    req.session.message = db_err_message;
                    // go back to the previous page
                    return res.redirect("back");
                }
                else {
                    var free_pack = [];
                    var premium_pack = [];
                    // get free and premium listing packets
                    results.forEach(list => {
                        if (list.type == "free")
                            free_pack.push(list);
                        else if (list.type == "premium")
                            premium_pack.push(list);
                    });
                    // render the category page now
                    res.render("public/category", {
                        title: "Category Listing",
                        categories: categories,
                        free_listing: free_pack,
                        premium_listing: premium_pack
                    });
                }
            });
        }
        });
    }
});

app.get("/category/all", (req, res) => {
    database.query(`SELECT * FROM categories`,(err, results) => {
        if (err) {
            // send error to dev
            console.log(err);
            // send error to the user
            req.session.message = db_err_message;
            // go back to the previous page
            return res.redirect("back");
        } else {
            var total_results = results.length;
            var pages = Math.ceil(total_results / PER_PAGE);
            var start, end;
            if (req.query.page) {
                if (req.query.page > pages || req.query.page < 1) {
                    // send error to the user
                    req.session.message = flash_message("Invalid page number for this category");
                    // go back to the previous page
                    return res.redirect("back");
                }
                start = (req.query.page - 1) * PER_PAGE;
                end = start + PER_PAGE;
            } else {
                start = 0;
                end = 20;
            }
            results = results.slice(start, end);
            res.render("public/category-all", {
                title: "All Categories",
                listings: results,
                total: total_results,
                page: {
                    total: pages,
                    this: req.query.page || 1
                }
            });
        }
    });
});

app.get("/premium", (req, res) => {
    return res.redirect("/subscription");
});
app.get("/premium/all", secure, member, (req, res) => {
    database.query(`SELECT * FROM listings WHERE type = ?`, ["premium"], (err, results) => {
        if (err) {
            // send error to dev
            console.log(err);
            // send error to the user
            req.session.message = db_err_message;
            // go back to the previous page
            return res.redirect("back");
        } else {
            var total_results = results.length;
            var pages = Math.ceil(total_results / PER_PAGE);
            var start, end;
            if (req.query.page) {
                if (req.query.page > pages || req.query.page < 1) {
                    // send error to the user
                    req.session.message = flash_message("Invalid page number for this category");
                    // go back to the previous page
                    return res.redirect("back");
                }
                start = (req.query.page - 1) * PER_PAGE;
                end = start + PER_PAGE;
            } else {
                start = 0;
                end = 20;
            }
            results = results.slice(start, end);
            res.render("public/category-list", {
                title: "All Premium Listings",
                listings: results,
                total: total_results,
                page: {
                    total: pages,
                    this: req.query.page || 1
                }
            });
        }
    });
});

app.post("/review", secure, (req, res) => {
    // get user inputs
    var stars = sanitize(req.body.stars);
    var review = sanitize(req.body.review);
    // get the target list id from page url
    var target = req.query.id;
    // get the username
    var user = req.session.username;
    // validity check
    try {
        if (stars <= 0) throw "No rating stars level was selected";
        else if (review.length < 50 || review.length > 500)
            throw "Review text length exceed limit";
        else {
            // get todays' date
            var date = new Date();
            // push data into database
            database.query(`INSERT INTO reviews (target_list, given_by, stars, description, date) VALUES (?,?,?,?,?)`, [
                target,
                user,
                stars,
                review,
                date
            ], (err) => {
                if (err) {
                    // send error to dev
                    console.log(err);
                    // send error to the user
                    req.session.message = db_err_message;
                    // go back to the previous page
                    return res.redirect("back");
                }
                else {
                    req.session.message = {
                        type: "success",
                        flash: "Submitted",
                        tail: `${stars} stars review to this page.`
                    }
                    // refresh the page
                    return res.redirect("back");
                }
            });
        }
    } catch (error) {
        // flash message
        req.session.message = {
            type: "danger",
            flash: "Error",
            tail: error
        }
        // refresh the page with flash message
        return res.redirect("back");
    }
});


app.get("/search", (req, res) => {

    if(req.query.key) {
        var text = sanitize(req.query.key);
        var searchText = "%"+text+"%";
        database.query(`SELECT * FROM listings WHERE name LIKE ?`, [searchText],
        (err, results) => {
            if (err) {
                // send error to dev
                console.log(err);
                // send error to the user
                req.session.message = db_err_message;
                // go back to the previous page
                return res.redirect("back");
            }
            else {
                var total_results = results.length;
                var pages = Math.ceil(total_results / PER_PAGE);
                var start, end;
                if (req.query.page) {
                    if (req.query.page > pages || req.query.page < 1) {
                        // send error to the user
                        req.session.message = flash_message("Invalid page number for this search");
                        // go back to the previous page
                        return res.redirect("back");
                    }
                    start = (req.query.page - 1) * PER_PAGE;
                    end = start + PER_PAGE;
                } else {
                    start = 0;
                    end = 20;
                }
                results = results.slice(start, end);
                res.render("public/search", {
                    title: text,
                    key: text,
                    listings: results,
                    total: total_results,
                    page: {
                        total: pages,
                        this: req.query.page || 1
                    }
                });
            }
        });
    } else {
        res.render("public/search", {
            title: "Search Listings",
            key: "",
            listings: [],
            page: {
                total: 0,
                this: 0
            }
        });
    }
});

app.post("/search", (req, res) => {
    var text = sanitize(req.body.text);
    try {
        if (!text) throw "No text given";
        else {
            res.redirect(`/list/search?key=${text}`);
        }
    } catch (error) {
        // flash message
        req.session.message = {
            type: "danger",
            flash: "Error",
            tail: error
        }
        // refresh the page with flash message
        return res.redirect("back");
    }
});

module.exports = app;