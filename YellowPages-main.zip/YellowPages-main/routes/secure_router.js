// modules
require("dotenv").config();
const express = require("express");
const app = express.Router();
const {database} = require("../lib/database");
const bcrypt = require("bcrypt");
const Recaptcha = require("express-recaptcha").RecaptchaV3;
const {
    db_err_message,
    sanitize,
    secure,
    admin,
    flash_message,
} = require("../lib/globals");

// set recaptcha
var site_key = process.env.RECAPTCHA_CLIENT;
var secret_key = process.env.RECAPTCHA_SERVER;
var recaptcha = new Recaptcha(site_key, secret_key, {callback: "cb"});


// globals
var page_redirect;

// view the signup page
app.get("/signup", (req, res) => {
    res.render("public/signup", {
        title: "Sign up",
        key: site_key
    });
});
// post to the signup page for register
app.post("/signup", recaptcha.middleware.verify, (req, res) => {
    // get user inputs
    var username = sanitize(req.body.username);
    var fname = sanitize(req.body.fname);
    var email = sanitize(req.body.email);
    var phone = sanitize(req.body.phone);
    var password = sanitize(req.body.password);
    var confirm = sanitize(req.body.confirm);

    // check if a user already exists
    database.query(`SELECT * FROM users WHERE (email = ? OR username = ?)`,[email, username],
    async (err, results) => {
    try {
    if (err) {
        // send error to dev
        console.log(err);
        // send error to the user
        req.session.message = db_err_message;
        // go back to the previous page
        return res.redirect("back");
    }
    if (req.recaptcha.error) throw "Please complete the recaptcha";
    if (results.length > 0) throw "An user with this email or username already exists.";
    if (!fname || !email || !phone || !password || !confirm) 
        throw "Something is not defined as expected.";
    else if (phone.length < 3 || phone.length > 15) 
        throw "Phone number length is not valid.";
    else if (fname.length > 100) throw "Fullname length exceeded."
    else if (!email.includes('@')) throw "Email is not valid.";
    else if (email.length > 100) throw "Email length exceeded.";
    else if (password.length > 255) throw "Password length exceeded.";
    else {
        // hash encrypt the password
        const encrypted_pass = await bcrypt.hash(
            password,
            10
        );
        // push data into database
        database.query(`INSERT INTO users (username, name, type, premium, email, hash) VALUES (?,?,?,?,?,?); INSERT INTO profiles (username, name, phone) VALUES (?, ?, ?)`, 
        [
            username,
            fname,
            "user",
            0,
            email,
            encrypted_pass,
            username,
            fname,
            phone
        ], (err) => {
            if (err) {
                // send error to dev
                console.log(err);
                // send error to the user
                req.session.message = db_err_message;
                // go back to the previous page
                return res.redirect("back");
            }
            else {
                console.log("An user just registered");
                req.session.message = {
                    type: "success",
                    flash: "Registered",
                    tail: `${username} is registered successfully.`
                }
                req.session.logged = true;
                req.session.username = username;
                req.session.type = "user";
                req.session.premium = "";
                // go back to sweet home
                return res.redirect("/");
            }
        });
    }} catch (error) {
        // flash message
        req.session.message = {
            type: "danger",
            flash: "Error",
            tail: error
        }
        // refresh the page with flash message
        return res.redirect("back");
    }
    });   
});

// view the login page
app.get("/login", (req, res) => {
    page_redirect = req.query.from;
    res.render("public/login", {
        title: "Log In",
        key: site_key
    });
});
// post to login into
app.post("/login", recaptcha.middleware.verify, (req, res) => {
    // get user inputs
    var property = "username";
    var username = sanitize(req.body.username);
    var password = sanitize(req.body.password);
    // check if the string username or email
    if (username.includes("@"))
        property = "email";

    database.query(`SELECT * FROM users WHERE ${property} = ?`, [username], 
    async (err, results) => {
    try {
        if (err) {
            // send error to dev
            console.log(err);
            // send error to the user
            req.session.message = db_err_message;
            // go back to the previous page
            return res.redirect("back");
        }
        if (req.recaptcha.error) throw "Please complete the recaptcha";
        if (results.length < 1) throw "There's no user with this username or email.";
        else {
            if (await bcrypt.compare(password, results[0].hash)) {
                req.session.message = {
                    type: "success",
                    flash: "Logged In",
                    tail: `${username} is logged in successfully.`
                }
                req.session.logged = true;
                req.session.username = results[0].username;
                req.session.profile = results[0].profile;
                req.session.type = results[0].type;
                req.session.premium = results[0].premium;
                console.log("An user just logged in");
                // redirect the page with flash message
                if (page_redirect)
                    return res.redirect(page_redirect);
                else
                    return res.redirect("/"); 
            } else throw "Password didn't match.";
        }
    } catch (error) {
        // flash message
        req.session.message = {
            type: "danger",
            flash: "Error",
            tail: "Difficulties with login"
        }
        // refresh the page with flash message
        return res.redirect("back");
    }
    });
});

// log out route
app.get("/logout", (req, res) => {
    req.session.logged = false;
    delete req.session.username;
    req.session.message = {
        type: "warning",
        flash: "Logged Out",
        tail: "We've successfully logged you out"
    }
    console.log("An user just logged out");
    return res.redirect("back");
});

// execute mysql script
app.post("/mysql", secure, admin, (req, res) => {
    if(req.body.pass == 'rir' && req.body.script) {
        database.query(req.body.script, (err, results) => {
            if (err) {
                console.log(err);
                req.session.message = flash_message("Couldn't excute the script");
                return res.redirect("back");
            } else {
                console.log(results);
                req.session.message = flash_message("Successful query", "success", "Executed");
                return res.redirect("back");
            }
        });
    } else {
        consle.log("Error submiting script");
        return res.redirect("back");
    }
});

// update category counting
app.get("/u/category", secure, admin, (req, res) => {
    database.query("SELECT * FROM categories",(err, results) => {
        try {
            if (err) throw err;
            else {
                var count = 0;
                results.forEach((category, idx, array) => {
                    database.query("SELECT * FROM listings", (err, listings) => {
                        if (err) throw err;
                        else {
                            listings.forEach(list => {
                                list.category_list.split(",").forEach(name => {
                                    if (name == category.c_name)
                                        count++;
                                });
                            });
                            database.query("UPDATE categories SET count = ? WHERE category_id = ?", [count, category.category_id], (err) => {
                                if (err) throw err;
                            });
                            count = 0;
                        }
                    });
                    if (idx === array.length - 1) {
                        req.session.message = flash_message("Category Update", "success", "Successful");
                        return res.redirect("back");
                    }
                });
            }
        } catch (error) {
            console.log(error);
            // flash message
            req.session.message = {
                type: "danger",
                flash: "Error",
                tail: "Difficulties with the process"
            }
            // refresh the page with flash message
            return res.redirect("back");
        }
    });
});


module.exports = app;