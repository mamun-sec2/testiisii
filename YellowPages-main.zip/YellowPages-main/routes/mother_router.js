// modules
const express = require("express");
const app = express.Router();


// routers
const secure_router = require("./secure_router");
const private_router = require("./private_router");
const listing_router = require("./listing_router");


// get homepage
app.get(["/", "/home"], (req, res) => {
    if (req.session.logged) {
        if (req.session.type == "admin") {
            res.redirect("/private/dashboard/admin");
        } else {
            res.redirect("/private/dashboard/user");
        }
    } else {
        res.render("public/home.ejs", {title: "Yellow Pages"});
    }
});

// secure routes
app.use("/secure", secure_router);

// private routes
app.use("/private", private_router);

// listing routes
app.use("/list", listing_router);

// home routes
app.get("/subscription", (req, res) => {
    res.render("public/subscription", {title: "Subscription"});
});
// about page
app.get("/about", (req, res) => {
    res.render("public/about", {title: "About Us"});
});

// test dynamic route
app.get("/test/:id", (req, res) => {
    res.render("misc/test", {title: "Dev Message", log: req.params.id});
});


// must be at the bottom
// 404 error
app.get("*", (req, res) => {
    res.render("misc/error404", {title: "404 Not Found"});
});


module.exports = app;