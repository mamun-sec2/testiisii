// modules
const express = require("express");
const app = express.Router();
const cloud = require("../lib/cloud");
const upload = require("../lib/multer");
const {database} = require("../lib/database");

const {
    db_err_message,
    secure,
    admin,
    user,
    sanitize,
    formatName
} = require("../lib/globals");

// user profile reponse (secure)
app.get("/user/profile", secure, (req, res) => {
    database.query(`SELECT * FROM profiles WHERE username = ?`, [req.session.username],
    (err, results) => {
        if (err) {
            // send error to dev
            console.log(err);
            // send error to the user
            req.session.message = db_err_message;
            // go back to the previous page
            return res.redirect("back");
        } else {
            return res.send(results[0]);
        }
    })
});

// user list uploaded reponse (secure)
app.get("/user/list/uploaded", secure, (req, res) => {
    database.query(`SELECT * FROM listings WHERE upload_by = ?`, [req.session.username],
    (err, results) => {
        if (err) {
           // send error to dev
           console.log(err);
           // send error to the user
           req.session.message = db_err_message;
           // go back to the previous page
           return res.redirect("back"); 
        } else {
            return res.send(results);
        }
    })
});

// user data reponse (secure)
app.get("/user/data", secure, (req, res) => {
    database.query(`SELECT * FROM users WHERE username = ?`, [req.session.username],
    (err, results) => {
        if (err) {
            // send error to dev
            console.log(err);
            // send error to the user
            req.session.message = db_err_message;
            // go back to the previous page
            return res.redirect("back"); 
        } else {
            return res.send(results[0]);
        }
    })
});

// user given reviews reponse (secure)
app.get("/user/reviews", secure, (req, res) => {
    database.query(`SELECT * FROM reviews WHERE given_by = ?`, [req.session.username],
    (err, results) => {
        if (err) {
            // send error to dev
            console.log(err);
            // send error to the user
            req.session.message = db_err_message;
            // go back to the previous page
            return res.redirect("back"); 
        } else {
            return res.send(results);
        }
    })
});

// user pending reponse (secure, admin)
app.get("/admin/pending", secure, admin, (req, res) => {
    database.query(`SELECT * FROM pending_list`,
    (err, results) => {
        if (err) {
            // send error to dev
            console.log(err);
            // send error to the user
            req.session.message = db_err_message;
            // go back to the previous page
            return res.redirect("back"); 
        } else {
            return res.send(results);
        }
    })
});

// admin all reviews reponse (secure, admin)
app.get("/admin/reviews", secure, admin, (req, res) => {
    database.query(`SELECT * FROM reviews`,
    (err, results) => {
        if (err) {
            // send error to dev
            console.log(err);
            // send error to the user
            req.session.message = db_err_message;
            // go back to the previous page
            return res.redirect("back"); 
        } else {
            return res.send(results);
        }
    })
});

// admin list approved reponse (secure, admin)
app.get("/admin/list/approved", secure, admin, (req, res) => {
    database.query(`SELECT * FROM listings WHERE approved_by = ?`, [req.session.username],
    (err, results) => {
        if (err) { 
            // send error to dev
            console.log(err);
            // send error to the user
            req.session.message = db_err_message;
            // go back to the previous page
            return res.redirect("back"); 
        } else {
            return res.send(results);
        }
    })
});

// admin all list reponse (secure, admin)
app.get("/admin/list/all", secure, admin, (req, res) => {
    database.query(`SELECT * FROM listings`,
    (err, results) => {
        if (err) { 
            // send error to dev
            console.log(err);
            // send error to the user
            req.session.message = db_err_message;
            // go back to the previous page
            return res.redirect("back"); 
        } else {
            return res.send(results);
        }
    })
});

// admin all categories reponse (secure, admin)
app.get("/admin/list/categories", secure, admin, (req, res) => {
    database.query(`SELECT * FROM categories`,
    (err, results) => {
        if (err) { 
            // send error to dev
            console.log(err);
            // send error to the user
            req.session.message = db_err_message;
            // go back to the previous page
            return res.redirect("back"); 
        } else {
            return res.send(results);
        }
    })
});

// users data reponse (secure, admin)
app.get("/admin/users", secure, admin, (req, res) => {
    database.query(`SELECT * FROM users`,
    (err, results) => {
        if (err) { 
            // send error to dev
            console.log(err);
            // send error to the user
            req.session.message = db_err_message;
            // go back to the previous page
            return res.redirect("back"); 
        } else {
            return res.send(results);
        }
    })
});

// get admin dashboard
app.get("/dashboard/admin", secure, admin, (req, res) => {
    database.query(`SELECT * FROM pending_list`, (err, results) => {
        if (err) {
            // send error to dev
            console.log(err);
            // send error to the user
            req.session.message = db_err_message;
            // go back to the previous page
            return res.redirect("back");
        } else {
            pending = results.length;
            res.render("private/admin", {
                title: "Admin Dashboard",                     
                pending: pending
            });
        }
    });
});

// get user dashboard
app.get("/dashboard/user", secure, user, (req, res) => {
    res.render("private/user", {
        title: "User Dashboard"
    });
});

// pending approval and rejection
app.post("/pending", secure, admin, (req, res) => {
    if (req.query.approve) {
        database.query(`SELECT * FROM pending_list WHERE pending_id = ?`, [req.query.approve],
        (err, results) => {
            if (err) {
                // send error to dev
                console.log(err);
                // send error to the user
                req.session.message = db_err_message;
                // go back to the previous page
                return res.redirect("back"); 
            }
            else {
                var {name, logo, category_list, upload_by, public, private, premium} = results[0];
                database.query(`INSERT INTO listings (type, name, logo, category_list, upload_by, approved_by) VALUES (?,?,?,?,?,?)`, 
                [
                    'free',
                    name,
                    logo,
                    category_list,
                    upload_by,
                    req.session.username
                ], (err, results) => {
                    if (err) {
                        // send error to dev
                        console.log(err);
                        // send error to the user
                        req.session.message = db_err_message;
                        // go back to the previous page
                        return res.redirect("back");
                    }
                    else {
                        var list_id = results.insertId;
                        var options = `{"updated_at":"","status":"","verified":false}`;
                        database.query(`INSERT INTO list_details (list_id, options, public, private, premium) VALUES (?,?,?,?, ?)`, [
                            list_id,
                            options,
                            public,
                            private,
                            premium
                        ], (err) => {
                            if (err) {
                                // send error to dev
                                console.log(err);
                                // send error to the user
                                req.session.message = db_err_message;
                                // go back to the previous page
                                return res.redirect("back"); 
                            }
                            else {
                                database.query(`DELETE FROM pending_list WHERE pending_id = ?`, [req.query.approve],
                                (err) => {
                                    if (err) {
                                        // send error to dev
                                        console.log(err);
                                        // send error to the user
                                        req.session.message = db_err_message;
                                        // go back to the previous page
                                        return res.redirect("back"); 
                                    }
                                    else res.send('1');
                                });
                            }
                        });
                    }
                });
            }
        });
    } else if (req.query.reject) {
        database.query(`DELETE FROM pending_list WHERE pending_id = ?`, [req.query.reject],
        (err) => {
            if (err) {
                res.send('-1');
            } else {
                res.send('2');
            }
        });
    }
});


// get add details
app.get("/add", secure, (req, res) => {
    var public_fields = [
        {
            name: "Logo",
            type: "file",
            help: "Allowed Files: jpg, jpeg, png,  Max Size: 100KB"
        },
        {
            name: "name",
            type: "text",
            required: true
        },
        {
            name: "Founded on",
            type: "date",
            required: true
        },
        {
            name: "Employee Count",
            type: "select",
            options: [
                "1 - 50",
                "50 - 100",
                "100 - 200",
                "100 - 500",
                "500 - 1000",
                "1000+"
            ]
        },
        {
            name: "short_description",
            type: "text",
            max: 500,
            required: true
        },
        {
            name: "Country Code",
            type: "text",
        },
        {
            name: "City",
            type: "text", 
        },
        {
            name: "Location",
            type: "location",
            required: true
        },
        {
            name: "Category List",
            type: "text",
            help: "Add multiple category with a comma in between."
        },
        {
            name: "A Branch of",
            type: "text"
        }
    ];
    var private_fields = [
        {
            name: "Webmaster Name",
            type: "text",
            required: true
        },
        {
            name: "Webmaster Email",
            type: "text",
            required: true
        },
        {
            name: "Webmaster Extension",
            type: "text",
            required: true
        },
        {
            name: "Long Description",
            type: "text",
            max: 1000
        },
        {
            name: "Type",
            type: "text",
        },
        {
            name: "Roles",
            type: "text",
        },
        {
            name: "UUID",
            type: "text",
        },
        {
            name: "Rank",
            type: "text",
        },
        {
            name: "Domain",
            type: "text",
            required: true
        },
        {
            name: "Homepage",
            type: "text",
        },
        {
            name: "Facebook",
            type: "text"
        },
        {
            name: "Linkedin",
            type: "text"
        },
        {
            name: "Twitter",
            type: "text"
        }
    ];
    var premium_fields = [
        {
            name: "Legal Name",
            type: "text"
        },
        {
            name: "Permalink",
            type: "text"
        },
        {
            name: "Email",
            type: "text"
        },
        {
            name: "Phone",
            type: "text"
        },
        {
            name: "Num Exits",
            type: "text"
        },
        {
            name: "Total Funding",
            type: "text"
        },
        {
            name: "Total Funding Currency",
            type: "text"
        },
        {
            name: "Last Funding On",
            type: "date"
        },
        {
            name: "Min Revenue",
            type: "number"
        },
        {
            name: "Max Revenue",
            type: "number"
        },
        {
            name: "Min Employee",
            type: "number"
        },
        {
            name: "Max Employee",
            type: "number"
        }
    ];
    res.render("private/add", {
        title: "Add Listing",
        public: public_fields,
        private: private_fields,
        premium: premium_fields,
        format: formatName
    });
});

// post add details to the database
app.post("/add", secure, upload.single("Logo"), async (req, res) => {
    var container = ["", "", ""];
    var index = 0, data = "", name = "", logo = "", category_list = "";
    try {
        name = req.body["name"];
        category_list = req.body["Category List"];
        if (req.file) {
            const result = await cloud.uploader.upload(req.file.path);
            logo = result.secure_url;
        }
        for (const field in req.body) {
            data = `"${sanitize(field)}":"${sanitize(req.body[field])}"`;
            if (field.includes("divider")) {
                container[index] = container[index].slice(0, -1);
                index++;
            } else {
                container[index] += data + ",";
            }
        }
    
        container[2] = container[2].slice(0, -1);
        var data_public = "{" + container[0] + "}";
        var data_private = "{" + container[1] + "}";
        var data_premium = "{" + container[2] + "}";
        
        database.query(`INSERT INTO pending_list(name, logo, category_list, upload_by, public, private, premium) VALUES(?,?,?,?,?,?,?)`, [
            name,
            logo,
            category_list,
            req.session.username,
            data_public,
            data_private,
            data_premium
        ], (err) => {
            if (err) {
                // send error to dev
                console.log(err);
                // send error to the user
                req.session.message = db_err_message;
                // go back to the previous page
                return res.redirect("back");
            } else {
                console.log(data_public, data_private, data_premium);
                req.session.message = {
                    type: "success",
                    flash: "Uploaded",
                    tail: "Your information are in the pending list."
                }
                // refresh the page with flash message
                return res.redirect("back");
            }
        });   
    } catch (error) {
        // send error to dev
        console.log(error);
        // send error to the user
        req.session.message = db_err_message;
        // go back to the previous page
        return res.redirect("back");
    }
});

app.post("/upload/profile", secure, upload.single("profile"), async (req, res) => {
    try {
        var profile;
        if (req.file.path) {
            const result = await cloud.uploader.upload(req.file.path);
            profile = result.secure_url;
        }
        database.query(`UPDATE users SET profile = ? WHERE username = ?`, [
            profile,
            req.session.username
        ], (err) => {
            if (err) {
                // send error to dev
                console.log(err);
                // send error to the user
                req.session.message = db_err_message;
                // go back to the previous page
                return res.redirect("back");
            } else {
                req.session.profile = profile;
                req.session.message = {
                    type: "success",
                    flash: "Uploaded",
                    tail: `Profile image of ${req.session.username}`
                }
                res.redirect("back");
            }
        });
    } catch (error) {
        // send error to dev
        console.log(error);
        // send error to the user
        req.session.message = db_err_message;
        // go back to the previous page
        return res.redirect("back");
    }
});


module.exports = app;