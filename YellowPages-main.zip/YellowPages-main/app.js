// modules 
const express = require("express");
const ejs_layout = require("express-ejs-layouts");
const session = require("express-session");
const path = require("path");
const {database} = require("./lib/database");

// settings
const app = express();
const port = process.env.PORT || 3000;
app.set("view engine", "ejs");
app.set('views', path.join(__dirname, 'views'));
app.use(express.urlencoded({ limit: '10mb', extended: true }));
app.use(express.static(path.join(__dirname + '/public')));
app.use(ejs_layout);

// session
// lasts for 45 minutes
app.use(session({
    secret: "rir360thedev",
    resave: false,
    saveUninitialized: false,
    cookie: {
        maxAge: 2700000
    }
}));

// flash message middleware
app.use((req, res, next) => {
    res.locals.message = req.session.message;
    res.locals.logged = req.session.logged;
    res.locals.username = req.session.username;
    res.locals.profile = req.session.profile;
    res.locals.type = req.session.type;
    res.locals.premium = req.session.premium;
    delete req.session.message;
    next();
});


// routers
const mother_router = require("./routes/mother_router");
// routes
app.use("/", mother_router);

function dbconnect() {
    database.connect(err => {
        if(err) {
            console.log('Database Error:', err);
            setTimeout(dbconnect, 2000);
        } else {
            console.log("Database Connected");
            app.listen(port);
            console.log("Server Started Successfully");
        }
    });
    database.on('error', function(err) {
        console.log('Database Error:', err);
        if(err.code === 'PROTOCOL_CONNECTION_LOST') { 
            dbconnect();
        } else {                                      
          throw err;
        }
    });
}

dbconnect();