
function simpleFormat(dateString) {
    var fulldate = "";
    var year = dateString.substring(0, 4);
    var month = dateString.substring(4, 6);
    var day = dateString.substring(6, 8);
    fulldate += year + "/" + month + "/" + day;
    return fulldate;
}
console.log(new Date("2022/01/05").toDateString());

