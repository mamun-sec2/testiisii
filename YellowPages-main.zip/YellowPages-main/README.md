# Yellow Pages by EaglesIdea (EIBull)

![image](https://user-images.githubusercontent.com/50569315/170838239-de8f1b45-7525-4a2c-911b-a58ad2d17ac2.png)


## Description
Yellow Pages website developed with Node JS. This is a global business indexing site. The Node JS server communicates with the MySQL server to populate the website with various company or business detailed information.
## About the Site
**The easier way to rank on Google!** <br/>
We've done the hard works! As one of Bangladesh largest and most established online business directories, Google often scans our information to deliver their results. In fact, EI BULL listings appear on the first page of search results.

## Dependencies
### Frontend
* Bootstrap (*5.0*)
* Jquery (*3.6.0*)
* Font-awesome (*6.1.1*)
### Backend
* Node JS
* Express JS (*4.17.3*)
* EJS (*3.1.6*)
* MySQL - NPM (*2.18.1*)
### Database
* MySQL

## Installation of the repo to local
* Install [VSCode](https://code.visualstudio.com/download).
* Install [Xampp](https://www.apachefriends.org/download.html).
* Install [Git](https://git-scm.com/downloads) + add the path to system variables.
* Clone the repository with VSCode. [Tutorial](https://docs.microsoft.com/en-us/azure/developer/javascript/how-to/with-visual-studio-code/clone-github-repository#:~:text=Open%20the%20command%20palette%20with,complete%20the%20sign%2Din%20process.)
* Open the repo and install npm modules by executing ``` npm install ```.
* Create a database from Xampp phpmyadmin panel. [Tutorial](https://www.javatpoint.com/creating-mysql-database-with-xampp)
* Import all required sql files. (`yellow-pages.sql` `categories.sql` `company_data.sql`)
* Create .env file in the project folder with appropiate variables.
* * DATABASE_HOST       = localhost
* * DATABASE_USER       = root
* * DATABASE_PASS       = ""
* * DATABASE_NAME       = "database name"
* * RECAPTCHA_CLIENT    = "google recaptcha client key"
* * RECAPTCHA_SERVER    = "google recaptcha secret key"
* * CLOUD_NAME          = "cloudinary cloud name"
* * CLOUD_KEY           = "cloudinary api key"
* * CLOUD_SECRET        = "cloudinary secret key"
* Start the project by executing ``` npm start ```.
* Visit ``` localhost:{port} ``` to preview the site.

## Deploy app on cPanel or shared hosting
* Create a MySQL database (note the name)
* Add new MySQL user (note name and password)
* Add a new user to the created database with "All Privileges".
* Import latest "yellow_pages.sql" to the database from phpMyAdmin.
* Upload the repo "YellowPages.zip" to the cPanel file manager.
* Extract the zip file that will create a folder (note the folder name)
* Select "setup Node JS app" option from exclusive section
* Create application by filling the form like this way:
* * Node JS version = choose the latest one
* * Application mode = choose development/production
* * Application root = folder name
* * Application URL = your domain name
* * Application startup file = app.js
* After creating the application click "Run NPM Install" from below.
* Then click "Run JS script" and choose "start".
* Add Environment Variables following the "template.env".
* Hopefully the application will be live after some minutes.

## Contact
Developer: Rejwan Islam Rizvy ([@rir360](https://github.com/rir360))
